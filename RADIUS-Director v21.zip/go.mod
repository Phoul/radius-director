module github.com/gobcn/radius-director

go 1.24.0

require gopkg.in/yaml.v3 v3.0.1

require (
	filippo.io/edwards25519 v1.2.0 // indirect
	github.com/go-sql-driver/mysql v1.10.0 // indirect
)
